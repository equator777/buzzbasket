import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    category: v.optional(v.string()),
    type: v.optional(v.union(v.literal("owned"), v.literal("affiliate"))),
  },
  handler: async (ctx, args) => {
    let query = ctx.db.query("products").withIndex("by_active", (q) => q.eq("isActive", true));
    
    if (args.category) {
      query = ctx.db.query("products").withIndex("by_category", (q) => q.eq("category", args.category!));
    }
    
    if (args.type) {
      query = ctx.db.query("products").withIndex("by_type", (q) => q.eq("type", args.type!));
    }
    
    const products = await query.collect();
    return products.filter(p => p.isActive);
  },
});

export const getById = query({
  args: { id: v.id("products") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    description: v.string(),
    price: v.number(),
    imageUrl: v.optional(v.string()),
    category: v.string(),
    type: v.union(v.literal("owned"), v.literal("affiliate")),
    affiliateLink: v.optional(v.string()),
    affiliateStore: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to create products");
    }

    return await ctx.db.insert("products", {
      ...args,
      isActive: true,
      createdBy: userId,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("products"),
    name: v.optional(v.string()),
    description: v.optional(v.string()),
    price: v.optional(v.number()),
    imageUrl: v.optional(v.string()),
    category: v.optional(v.string()),
    affiliateLink: v.optional(v.string()),
    affiliateStore: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to update products");
    }

    const product = await ctx.db.get(args.id);
    if (!product || product.createdBy !== userId) {
      throw new Error("Product not found or unauthorized");
    }

    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);
  },
});

export const remove = mutation({
  args: { id: v.id("products") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be logged in to delete products");
    }

    const product = await ctx.db.get(args.id);
    if (!product || product.createdBy !== userId) {
      throw new Error("Product not found or unauthorized");
    }

    await ctx.db.delete(args.id);
  },
});

export const myProducts = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    return await ctx.db
      .query("products")
      .withIndex("by_creator", (q) => q.eq("createdBy", userId))
      .collect();
  },
});
