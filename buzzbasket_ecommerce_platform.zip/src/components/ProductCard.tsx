import { Doc } from "../../convex/_generated/dataModel";

interface ProductCardProps {
  product: Doc<"products">;
}

export function ProductCard({ product }: ProductCardProps) {
  const handleClick = () => {
    if (product.type === 'affiliate' && product.affiliateLink) {
      window.open(product.affiliateLink, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div 
      className={`bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow ${
        product.type === 'affiliate' ? 'cursor-pointer' : ''
      }`}
      onClick={handleClick}
    >
      <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-t-lg bg-gray-200">
        {product.imageUrl ? (
          <img
            src={product.imageUrl}
            alt={product.name}
            className="h-48 w-full object-cover object-center"
          />
        ) : (
          <div className="h-48 w-full bg-gray-100 flex items-center justify-center">
            <svg className="h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
        )}
      </div>
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold text-gray-900 truncate">{product.name}</h3>
          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
            product.type === 'owned' 
              ? 'bg-green-100 text-green-800' 
              : 'bg-blue-100 text-blue-800'
          }`}>
            {product.type === 'owned' ? 'Our Product' : 'Affiliate'}
          </span>
        </div>
        
        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{product.description}</p>
        
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-indigo-600">
            ${product.price.toFixed(2)}
          </span>
          
          {product.type === 'affiliate' && product.affiliateStore && (
            <span className="text-xs text-gray-500">
              via {product.affiliateStore}
            </span>
          )}
        </div>
        
        <div className="mt-3">
          <span className="inline-block bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded-full">
            {product.category}
          </span>
        </div>
        
        {product.type === 'affiliate' && (
          <div className="mt-3">
            <button className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors text-sm font-medium">
              View on {product.affiliateStore || 'Partner Site'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
