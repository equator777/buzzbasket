import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState } from "react";
import { ProductGrid } from "./components/ProductGrid";
import { AdminPanel } from "./components/AdminPanel";
import { Header } from "./components/Header";
import { CategoryFilter } from "./components/CategoryFilter";

export default function App() {
  const [currentView, setCurrentView] = useState<'shop' | 'admin'>('shop');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [productType, setProductType] = useState<'all' | 'owned' | 'affiliate'>('all');

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        currentView={currentView} 
        onViewChange={setCurrentView}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Authenticated>
          {currentView === 'shop' ? (
            <div className="space-y-8">
              <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Welcome to BuzzBasket
                </h1>
                <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                  Discover amazing products from our curated collection and trusted affiliate partners
                </p>
              </div>
              
              <CategoryFilter
                selectedCategory={selectedCategory}
                onCategoryChange={setSelectedCategory}
                productType={productType}
                onProductTypeChange={setProductType}
              />
              
              <ProductGrid 
                category={selectedCategory || undefined}
                type={productType === 'all' ? undefined : productType}
              />
            </div>
          ) : (
            <AdminPanel />
          )}
        </Authenticated>

        <Unauthenticated>
          <div className="max-w-md mx-auto mt-16">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">BuzzBasket</h1>
              <p className="text-xl text-gray-600">
                Your premier destination for ecommerce and affiliate marketing
              </p>
            </div>
            <SignInForm />
          </div>
        </Unauthenticated>
      </main>
      
      <Toaster />
    </div>
  );
}
